# detect-sentence-change
Detect changes in two difference sentences, addition or deletion of words and shifting of words using HTML + jQuery + Bootstrap
