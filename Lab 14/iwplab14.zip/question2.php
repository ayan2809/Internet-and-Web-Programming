<?php

$xml_data = simplexml_load_file("question1.xml") or 
die("Error: Object Creation failure");

$count=0;
foreach ($xml_data->children() as $data)
{
    //display each sub element in xml file
    if($data->marks > 40)
    {
        $count++;
    }
    
}
echo  "Number of students with greater than 40 is ", $count."<br>";
?>