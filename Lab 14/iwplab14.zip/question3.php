<?php

$xml_data = simplexml_load_file("question3.xml") or 
die("Error: Object Creation failure");

$x=0;
for ($x = 0; $x <= 6; $x++) {
    echo "<div id ='$x'>The number is: $xml_data->children </div><br>";
  }

foreach ($xml_data->children() as $data)
{
    echo "Course Code : ", $data->coursecode . "   ";
    echo "Course Name: ", $data->coursename . "   ";
    echo "Course Slot : ", $data->slot . "   ";
    echo "<br><br>";
    
}
// echo  "Number of students with greater than 40 is ", $count."<br>";
?>